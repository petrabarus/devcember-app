import json

def getListComment(event, context):
    body = {
        "comments": [
            {
                "id": 1,
                "name": 'Petra',
                "comment": 'Hello World!',
                "createdAt": 1481924490,
            },
            {
                "id": 2,
                "name": 'Petra',
                "comment": 'Hello World!',
                "createdAt": 1481924300,
            }
        ]
    }
    response = {
        "statusCode": 200,
        "body": json.dumps(body),
        "headers": {
            'Access-Control-Allow-Origin': '*'
        }
    }

    return response
